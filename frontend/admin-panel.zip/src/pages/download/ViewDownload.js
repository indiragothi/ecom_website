import React from 'react'

const ViewDownload = () => {
  return (
    <div className='content-wrapper'>
      <div className='row'>

          <div class="col-lg-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title text-primary">Download</h4>
                  <p class="card-description">
                    Total Table : 8
                  </p>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Sr.No.</th>
                          <th>Profile</th>
                          <th>VatNo.</th>
                          <th>Created</th>
                           
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>Jacob</td>
                          <td>53275531</td>
                          <td>12 May 2017</td>
                           
                        </tr>
                        <tr>
                          <td>2</td>
                          <td>Messsy</td>
                          <td>53275532</td>
                          <td>15 May 2017</td>
                           
                        </tr>
                        <tr>
                          <td>3</td>
                          <td>John</td>
                          <td>53275533</td>
                          <td>14 May 2017</td>
                           
                        </tr>
                        <tr>
                          <td>4</td>
                          <td>Peter</td>
                          <td>53275534</td>
                          <td>16 May 2017</td>
                           
                        </tr>
                        <tr>
                          <td>5</td>
                          <td>Dave</td>
                          <td>53275535</td>
                          <td>20 May 2017</td>
                           
                        </tr>
                        <tr>
                          <td>3</td>
                          <td>John</td>
                          <td>53275533</td>
                          <td>14 May 2017</td>
                           
                        </tr>
                        <tr>
                          <td>4</td>
                          <td>Peter</td>
                          <td>53275534</td>
                          <td>16 May 2017</td>
                           
                        </tr>
                        <tr>
                          <td>5</td>
                          <td>Dave</td>
                          <td>53275535</td>
                          <td>20 May 2017</td>
                           
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
          </div>

          
          <div class="col-lg-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title text-primary">Add Label</h4>
                   
                  <form class="forms-sample">

                    <div class="form-group">
                      <label for="exampleInputUsername1">Label Title (Black Label)</label>
                      <input type="text" class="form-control" id="exampleInputUsername1" placeholder="Label Title"/>
                    </div> 

                    <div class="form-group">
                      <label for="exampleTextarea1">Label Description (Red Label)</label>
                      <textarea class="form-control" id="exampleTextarea1" rows="6" placeholder='Description'></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary mr-2">Submit</button>

                  </form>
                </div>
              </div>
          </div>
  
      </div>
    </div>
  )
}

export default ViewDownload
