import React from 'react'

const ViewTemplate = () => {
  return (
    <div className='content-wrapper'>

        <div className='row'>

            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body ">
                  <div className='d-flex '>
                    <h4 class="card-title text-primary ">View All Template</h4>
                  </div>

                  <div className='row'>
                    <div className='col-lg-3'>
                       <div className='card shadow-3 card-temp d-flex justify-content-center align-items-center'>
                        1
                      </div>
                    </div>
                    <div className='col-lg-3'>
                       <div className='card shadow-3 card-temp d-flex justify-content-center align-items-center'>
                        2
                      </div>
                    </div>
                    <div className='col-lg-3'>
                       <div className='card shadow-3 card-temp d-flex justify-content-center align-items-center'>
                        3
                      </div>
                    </div>
                    <div className='col-lg-3'>
                       <div className='card shadow-3 card-temp d-flex justify-content-center align-items-center'>
                        4
                      </div>
                    </div>
                  </div>

                  <div className='row'>
                    <div className='col-lg-3 my-3'>
                       <div className='card shadow-3 card-temp d-flex justify-content-center align-items-center'>
                        1
                      </div>
                    </div>
                    <div className='col-lg-3 my-3'>
                       <div className='card shadow-3 card-temp d-flex justify-content-center align-items-center'>
                        2
                      </div>
                    </div>
                    <div className='col-lg-3 my-3'>
                       <div className='card shadow-3 card-temp d-flex justify-content-center align-items-center'>
                        3
                      </div>
                    </div>
                    <div className='col-lg-3 my-3'>
                       <div className='card shadow-3 card-temp d-flex justify-content-center align-items-center'>
                        4
                      </div>
                    </div>
                  </div>
                   
                </div>
              </div>
            </div>

        </div>

    </div>
  )
}

export default ViewTemplate
