import React from 'react'

const ViewProduct = () => {

  return (

    <div className='content-wrapper'>
        
        <div className='row'>

            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div className='d-flex justify-content-between'>
                    <h4 class="card-title text-primary ">Categories</h4>
                    {/* <Link className='text-primary border rounded-pill py-3 px-4 add-product-btn' to={'/add-product'}> Add Product </Link>   */}
                    <a type="button" class="btn btn-outline-primary mb-3 mr-3" href="/add-product" >Add Product</a>
                     
                  </div>
                   
                   
                </div>
              </div>
            </div>

        </div>
    </div>
    
  )
}

export default ViewProduct
