import React from 'react'

const AddProduct = () => {
  return (
    <div className='content-wrapper'>
        
        <div className='row'>

            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <div className='d-flex justify-content-between'>
                        <h4 class="card-title text-primary ">Add Product</h4>
                        <p className='card-description'></p>
                    </div>

                    <div className='row'>
                        <div className='form-group col-md-4'>
                            <label for="exampleInputUsername1">Product Name</label>
                            <input type="text" name='name' class="form-control" id="name" placeholder="Enter Product Name"/>
                        </div>
                        <div className='form-group col-md-4'>
                            <label for="exampleInputUsername1">Title</label>
                            <input type="text" name='title' class="form-control" id="exampleInputUsername1" placeholder="Enter Title"/>
                        </div>
                        <div className='form-group col-md-4'>
                            <label for="exampleInputUsername1">Review</label>
                            <input type="text" name='reviews' class="form-control" id="exampleInputUsername1" placeholder="Enter Review"/>
                        </div>
                    </div>

                    <div className='row'>
                        <div className='form-group col-md-4'>
                            <label for="exampleInputUsername1">Price</label>
                            <input type="number" name='price' min="0" class="form-control" id="exampleInputUsername1" placeholder="Enter Price"/>
                        </div>
                        <div className='form-group col-md-4'>
                            <label for="exampleInputUsername1">Stock</label>
                            <input type="number" name='stock' min="0" class="form-control" id="exampleInputUsername1" placeholder="Enter Stock"/>
                        </div>
                        <div className='form-group col-md-4'>
                            <label for="exampleInputUsername1">No. of Reviews</label>
                            <input type="number" name='numOfReviews' min="0" class="form-control" id="exampleInputUsername1" placeholder="No. of Reviews"/>
                        </div>
                    </div>

                    <div className='row'>
                        <div className='form-group col-md-4'>
                            <label for="exampleInputUsername1">Rating</label>
                            <input type="number" name='rating' min="0" max="5" class="form-control" id="exampleInputUsername1" placeholder="Enter Rating"/>
                        </div>
                        <div className='form-group col-md-4'>
                            <label for="exampleInputUsername1">Category</label>
                            <input type="number" name='rating' min="0" max="5" class="form-control" id="exampleInputUsername1" placeholder="Choose Category"/>
                        </div>
                          
                    </div>

                    <div className='row'>
                        <div class="form-group col-md-8">
                            <label for="exampleTextarea1">Description</label>
                            <textarea class="form-control" id="exampleTextarea1" rows="4" placeholder='Enter Description'></textarea>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                   
                   
                </div>
              </div>
            </div>

        </div>
    </div>
  )
}

export default AddProduct
