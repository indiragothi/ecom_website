import React from 'react'
import { RxDashboard } from "react-icons/rx";
import { FaUsers } from "react-icons/fa";
import { FaUser } from "react-icons/fa";
import { MdSubscriptions } from "react-icons/md";
import { BiCategory } from "react-icons/bi";
import { BiFileBlank } from "react-icons/bi";
import { FaDownload } from "react-icons/fa6";
import { IoMdNotifications } from "react-icons/io";
import { FaProductHunt } from "react-icons/fa";
import { Link } from 'react-router-dom';

const Sidebar = () => {
  return (
    <>
        <nav class="sidebar sidebar-offcanvas sidebar-contain" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <Link class="nav-link" to='/dashboard' >
              <i class="menu-icon"><RxDashboard /></i>
              <span class="menu-title">Dashboard</span>
            </Link>
          </li>
          <li class="nav-item">
            <Link class="nav-link" to='/product' >
              <i class="menu-icon"><FaProductHunt /></i>
              <span class="menu-title">Product</span>
            </Link>
          </li>
          <li class="nav-item">
            <Link class="nav-link" data-toggle="collapse" to={'/users'} aria-expanded="false" aria-controls="ui-basic"> 
              <i className='menu-icon'><FaUsers /></i>
              <span class="menu-title">Users</span>
            </Link>
          </li>
          <li class="nav-item">
            <Link class="nav-link" data-toggle="collapse" to={'/viewTemplate'} aria-expanded="false" aria-controls="form-elements">
              <i class="menu-icon"><FaUser /></i>
              <span class="menu-title">Templates</span>
            </Link>
          </li>
          <li class="nav-item">
            <Link class="nav-link" data-toggle="collapse" to={'/subscription'} aria-expanded="false" aria-controls="charts">
              <i class="menu-icon"><MdSubscriptions /></i>
              <span class="menu-title">Subscription Plan</span>
            </Link>
          </li>
          <li class="nav-item">
            <Link class="nav-link" data-toggle="collapse" to={'/viewCategory'} aria-expanded="false" aria-controls="tables">
              <i class="menu-icon"><BiCategory /></i>
              <span class="menu-title">Categories</span>
            </Link>
          </li>
          <li class="nav-item">
            <Link class="nav-link" data-toggle="collapse"  to={'/viewPages'} aria-expanded="false" aria-controls="icons">
              <i class="menu-icon"><BiFileBlank /></i>
              <span class="menu-title">Pages</span>
            </Link>
          </li>
          <li class="nav-item">
            <Link class="nav-link" data-toggle="collapse" to={'/viewDownload'} aria-expanded="false" aria-controls="auth">
              <i class="menu-icon"><FaDownload /></i>
              <span class="menu-title">Downloads</span> 
            </Link>
          </li>
          <li class="nav-item">
            <Link class="nav-link" data-toggle="collapse" to={'/viewNotification'} aria-expanded="false" aria-controls="error">
              <i class="menu-icon"><IoMdNotifications /></i>
              <span class="menu-title">Notification</span>
            </Link>
          </li>
        </ul>
        </nav>
      
    </>
  )
}

export default Sidebar
