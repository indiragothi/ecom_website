import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Dashboard from './pages/dashboard/Dashboard'
import Users from './pages/users/Users';
import ViewCategory from './pages/viewCategory/ViewCategory';
import ViewNotification from './pages/viewNotification/ViewNotification';
import Subscription from './pages/subscription/Subscription';
import ViewTemplate from './pages/template/ViewTemplate'
import ViewDownload from './pages/download/ViewDownload';
import ViewPages from './pages/viewPage/ViewPages';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import ViewProduct from './pages/viewProduct/ViewProduct';
import AddProduct from './components/modals/AddProduct';
 
 
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<App/>}>
          <Route index path='/dashboard' element={<Dashboard/>} />
          <Route path='/product' element={<ViewProduct/>} />
          <Route path='/users' element={<Users/>}/>
          <Route path='/viewTemplate' element={<ViewTemplate/>} />
          <Route path='/subscription' element={<Subscription/>}/>
          <Route path='/viewCategory' element={<ViewCategory/>}/>
          <Route path='/viewPages' element={<ViewPages/>}/>
          <Route path='/viewDownload' element={<ViewDownload/>}/>
          <Route path='/viewNotification' element={<ViewNotification/>}/>
          <Route path='/login' element={<Login/>} />
          <Route path='/register' element={<Register/>} />
          <Route path='/add-product' element={<AddProduct/>}/>
        </Route>
      </Routes>
      
    </BrowserRouter>
  </React.StrictMode>
);
 